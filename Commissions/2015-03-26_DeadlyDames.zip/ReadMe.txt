Dear Jacqueline,

Included are: 
	two versions (front and back) of a standard 3.5 x 2 inch business card with an 1/8th inch bleed all around, in .psd and .pdf format; 

	the logo source file in .psd format, as vector shapes which can be resized to fit a t-shirt of arbitrary dimension; 

	source files for all fonts used in the layout, should changes need to be made in future.

I hope these will be sufficient for your needs. Please contact me at camgayford@gmail.com if further revisions or alternate file formats are necessary (per our arrangement, since you have agreed to pay me an interest in t-shirt sales using this design, I will consider that payment for minor revisions in future).

It's been a pleasure doing business with you!
	Cheers,
	Cam Gayford